import sqlite3
"nursery.db"
conn = sqlite3.connect("nursery.db")

s=''' pragma table_info(plants) '''
d=conn.execute(s)
print(d)
for i in d:
    print(i)

s1=''' pragma table_info(orders) '''
d1=conn.execute(s1)
print(d1)
for i in d1:
    print(i)


s2=''' pragma table_info(complaint) '''
d2=conn.execute(s2)
print(d2)
for i in d2:
    print(i)