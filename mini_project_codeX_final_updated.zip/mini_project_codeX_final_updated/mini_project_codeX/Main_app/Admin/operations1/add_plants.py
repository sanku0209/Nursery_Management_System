import sqlite3
"nursery.db"
conn = sqlite3.connect("nursery.db")

def add_plants():
    id = int(input("enter plant id  :"))
    name = input("enter plant name:")
    pieces = int(input("enter no. of plant pieces: "))
    price =int(input("enter price per piece :"))
    data1 = {}
    data1['id'] = id
    data1['name'] = name
    data1['pieces'] = pieces
    data1['price']=price
    conn.execute('''
                insert into plants(id,name,pieces,price) values(?,?,?,?)
       ''', (data1.get("id"), data1.get("name"), data1.get("pieces"),data1.get("price")))
    conn.commit()
    print("data inserted successfully!!!")
    return data1
