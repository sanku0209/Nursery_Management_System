from Main_app.Admin.operations1 import orders_view as o
from Main_app.Admin.operations1 import add_plants as ap
from Main_app.Admin.operations1 import delete_plants as dp
from Main_app.Admin.operations1 import complaints_view as cv
from Main_app.Admin.operations1 import view_database as v
def admin_portal():
    while(True):
        print('''
        WELCOME OWNERS!!!.
        1.See Collection of plants
        2.Add plants
        3.Delete Plants
        4.orders
        5.complaints 
        6.back
        ''')
        print("choose any option :")
        c=int(input())
        if c == 1:
            v.view_database()

        elif c == 2:
            ap.add_plants()

        elif c == 3:
            n = input("Enter the plant name to delete:")
            dp.plant_del(n)
        elif c == 4:
            o.orders_view()
        elif c == 5:
            cv.complaints_view()
        else :
            break