from Main_app.Customer.operations2 import order_plants as op
from Main_app.Customer.operations2 import complaints as cm
def customer_portal():
    while(True):
        print('''
        WELCOME CUSTOMERS TO codeX NURSERY!!!
        1.order plants
        2.Complaints
        3.Back
        ''')
        print("choose any option :")
        cho=int(input())
        if cho == 1:
            op.show_plants()
            op.order_plants()


        elif cho == 2:
            cm.complaints()
        else :
            break