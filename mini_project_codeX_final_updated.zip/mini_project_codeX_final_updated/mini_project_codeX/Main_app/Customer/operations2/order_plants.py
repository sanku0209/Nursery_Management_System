from Main_app.Customer.operations2 import Reg_log as rl
import sqlite3
"nursery.db"
conn = sqlite3.connect("nursery.db")
def show_plants():
    print("These are the plants available in nursery")
    l=conn.execute("select * from plants")
    for i in l:
        print(i)
    conn.commit()
def order_plants():
        print('''1.Register - New User \t  2.Login - Old User''')
        choice = int(input('enter your choice:'))

        if choice == 1:
            rl.register()
        elif choice == 2:
            rl.login()
        else:
            print("choose correct option")


