import csv
from Main_app.Customer.operations2 import orders as o
def register():
     with open("credentials.csv","a") as f:
         writer=csv.writer(f)
         name=input("enter userName:")
         password=input("create password")
         repassword=input("enter password again")
         address=input("enter address")
         phno=int(input("enter phone no:"))
         if password==repassword:
             writer.writerow([name,password,address,phno])
             print("Registration is successfull.login to continue..")
         else:
             print("try again!!")

def login():
    name=input("enter userName:")
    password=input("enter password:")
    with open("credentials.csv","r") as f:
        reader=csv.reader(f)
        for row in reader:
             if len(row) > 0:
                  if name== row[0] and password==row[1]:
                       print("welcome ",name,"Happy Shopping !!")
                       o.your_orders()
                       break
        else:
             print("Please try Again!!")
