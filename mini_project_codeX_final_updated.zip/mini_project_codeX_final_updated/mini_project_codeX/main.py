import sqlite3
"nursery.db"
conn = sqlite3.connect("nursery.db")
#l=conn.execute('''select * from orders ''')
#for i in l:
#    print(i)

#conn.execute('''delete from orders''')
#conn.commit()

#l=conn.execute('''select * from orders ''')
#for i in l:
#    print(i)

#x=conn.execute('''SELECT count(*) FROM orders''')
#for i in x:
 #   print(i)
#print(x)


p=conn.execute("select o_id from orders Order by o_id DESC LIMIT 1")
for i in p:
    print(i)
